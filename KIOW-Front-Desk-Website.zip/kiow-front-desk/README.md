# KIOW Front Desk

A free, static, responsive aviation reference website. No backend, database, account, API key, or paid hosting required.

## Preview locally

Open `index.html` in a browser. The search, lookup, pricing, and calculator run entirely in the browser.

## Publish on GitHub Pages

1. Sign in at https://github.com and select **New repository**.
2. Name it `kiow-front-desk`, set visibility to **Public**, and create the repository.
3. Select **Add file → Upload files**, and upload `index.html`, `styles.css`, and `app.js` from this folder. Commit changes. (`README.md` is optional.)
4. Open **Settings → Pages** in the repository.
5. Under **Build and deployment**, choose **Deploy from a branch**. Set branch to **main** and folder to **/(root)**, then save.
6. After deployment, open `https://YOUR-USERNAME.github.io/kiow-front-desk/` (replace YOUR-USERNAME).

GitHub Pages sites are public on the internet; knowing the link is not required for access. Do not upload confidential information.

## Customize

- Website name and contact details: edit `index.html`.
- Colors and layout: edit `styles.css`.
- Handling fees, winter hangar rates, fuel thresholds, services, aircraft models and category mappings: edit `app.js`.
- Fuel prices default to zero so you must enter the current selling price in the calculator.

## Pricing assumptions

Handling fee tiers:
- Small Jet / Small Turbo: $75, waived with 50 gallons, winter hangar $200/night
- Light Jet / Large Turbo: $120, waived with 80 gallons, winter hangar $300/night
- Mid-Size Jet: $150, waived with 100 gallons, winter hangar $425/night
- Large Jet: $300, waived with 200 gallons, winter hangar $500/night

Other services: after-hours $150/hour; overnight ramp parking $0; GPU $75; lavatory $75; preheat $25/engine; plug-in $10/engine.

The calculator assumes combined Jet-A and 100LL gallons qualify toward the handling waiver. If your FBO policy differs, change the `qualifying` expression in `calculate()` inside `app.js`. Aircraft tier assignments are suggested only; review and adjust before operational use. Taxes and other fees are not included.

## Maintenance

GitHub Pages automatically republishes when you commit updated files to the configured branch. No build process is required.
