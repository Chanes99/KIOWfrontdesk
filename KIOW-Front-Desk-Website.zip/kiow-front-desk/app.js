'use strict';
// Edit these values to maintain the public reference website.
const TIERS=[
 {id:'small',name:'Small Jet / Small Turbo',handling:75,waiver:50,hangar:200},
 {id:'light',name:'Light Jet / Large Turbo',handling:120,waiver:80,hangar:300},
 {id:'mid',name:'Mid-Size Jet',handling:150,waiver:100,hangar:425},
 {id:'large',name:'Large Jet',handling:300,waiver:200,hangar:500}
];
const SERVICES=[['After-hours callout','$150 / hour'],['Overnight ramp parking','$0'],['Lavatory service','$75 / service'],['GPU service','$75 / service'],['Preheat','$25 / engine'],['Plug-in','$10 / engine']];
// This is a curated reference list, not a complete type-certificate database.
// Fee tiers are operational estimates; confirm local policies for each aircraft.
const DATA=[
 ['Cirrus','Vision Jet SF50','Very Light Jet','Single turbofan','small'],
 ['Honda','HA-420 HondaJet','Very Light Jet','Twin turbofan','small'],
 ['Cessna','Citation Mustang 510','Very Light Jet','Twin turbofan','small'],
 ['Cessna','Citation M2 525','Very Light Jet','Twin turbofan','small'],
 ['Embraer','Phenom 100','Very Light Jet','Twin turbofan','small'],
 ['Eclipse','Eclipse 500','Very Light Jet','Twin turbofan','small'],
 ['Eclipse','Eclipse 550','Very Light Jet','Twin turbofan','small'],
 ['Cessna','Citation CJ1 / CJ1+','Light Jet','Twin turbofan','light'],
 ['Cessna','Citation CJ2 / CJ2+','Light Jet','Twin turbofan','light'],
 ['Cessna','Citation CJ3 / CJ3+','Light Jet','Twin turbofan','light'],
 ['Cessna','Citation CJ4 / CJ4 Gen2','Light Jet','Twin turbofan','light'],
 ['Cessna','Citation Bravo','Light Jet','Twin turbofan','light'],
 ['Cessna','Citation Ultra','Light Jet','Twin turbofan','light'],
 ['Cessna','Citation Encore / Encore+','Light Jet','Twin turbofan','light'],
 ['Embraer','Phenom 300 / 300E','Light Jet','Twin turbofan','light'],
 ['Pilatus','PC-24','Light Jet','Twin turbofan','light'],
 ['Beechcraft','Premier I / IA','Light Jet','Twin turbofan','light'],
 ['Learjet','Learjet 31 / 31A','Light Jet','Twin turbofan','light'],
 ['Learjet','Learjet 40 / 40XR','Light Jet','Twin turbofan','light'],
 ['Learjet','Learjet 45 / 45XR','Light Jet','Twin turbofan','light'],
 ['Nextant','400XT / 400XTi','Light Jet','Twin turbofan','light'],
 ['Hawker','400XP','Light Jet','Twin turbofan','light'],
 ['Cessna','Citation Excel 560XL','Mid-Size Jet','Twin turbofan','mid'],
 ['Cessna','Citation XLS / XLS+','Mid-Size Jet','Twin turbofan','mid'],
 ['Cessna','Citation XLS Gen2','Mid-Size Jet','Twin turbofan','mid'],
 ['Cessna','Citation Latitude','Mid-Size Jet','Twin turbofan','mid'],
 ['Cessna','Citation Sovereign / Sovereign+','Mid-Size Jet','Twin turbofan','mid'],
 ['Cessna','Citation X / X+','Super Mid-Size Jet','Twin turbofan','large'],
 ['Cessna','Citation Longitude','Super Mid-Size Jet','Twin turbofan','large'],
 ['Learjet','Learjet 60 / 60XR','Mid-Size Jet','Twin turbofan','mid'],
 ['Learjet','Learjet 70 / 75','Mid-Size Jet','Twin turbofan','mid'],
 ['Hawker','Hawker 800XP / 850XP','Mid-Size Jet','Twin turbofan','mid'],
 ['Hawker','Hawker 900XP','Mid-Size Jet','Twin turbofan','mid'],
 ['Hawker','Hawker 4000','Super Mid-Size Jet','Twin turbofan','large'],
 ['Embraer','Legacy 450','Mid-Size Jet','Twin turbofan','mid'],
 ['Embraer','Praetor 500','Mid-Size Jet','Twin turbofan','mid'],
 ['Embraer','Legacy 500','Super Mid-Size Jet','Twin turbofan','large'],
 ['Embraer','Praetor 600','Super Mid-Size Jet','Twin turbofan','large'],
 ['Bombardier','Challenger 300 / 350','Super Mid-Size Jet','Twin turbofan','large'],
 ['Bombardier','Challenger 3500','Super Mid-Size Jet','Twin turbofan','large'],
 ['Bombardier','Challenger 604 / 605','Large Jet','Twin turbofan','large'],
 ['Bombardier','Challenger 650','Large Jet','Twin turbofan','large'],
 ['Bombardier','Global 5000 / 5500','Large Jet','Twin turbofan','large'],
 ['Bombardier','Global 6000 / 6500','Large Jet','Twin turbofan','large'],
 ['Bombardier','Global 7500 / 8000','Large Jet','Twin turbofan','large'],
 ['Gulfstream','G150','Mid-Size Jet','Twin turbofan','mid'],
 ['Gulfstream','G200','Super Mid-Size Jet','Twin turbofan','large'],
 ['Gulfstream','G280','Super Mid-Size Jet','Twin turbofan','large'],
 ['Gulfstream','G450','Large Jet','Twin turbofan','large'],
 ['Gulfstream','G500 / G550','Large Jet','Twin turbofan','large'],
 ['Gulfstream','G600 / G650 / G650ER','Large Jet','Twin turbofan','large'],
 ['Gulfstream','G700 / G800','Large Jet','Twin turbofan','large'],
 ['Dassault','Falcon 50 / 50EX','Large Jet','Three turbofans','large'],
 ['Dassault','Falcon 900 / 900EX / 900LX','Large Jet','Three turbofans','large'],
 ['Dassault','Falcon 2000 / 2000EX / 2000LXS','Large Jet','Twin turbofan','large'],
 ['Dassault','Falcon 7X / 8X','Large Jet','Three turbofans','large'],
 ['Dassault','Falcon 6X','Large Jet','Twin turbofan','large'],
 ['Embraer','Legacy 600 / 650','Large Jet','Twin turbofan','large'],
 ['Embraer','Lineage 1000','Large Jet','Twin turbofan','large'],
 ['Beechcraft','King Air C90 / C90GT','Twin Turboprop','Twin turboprop','small'],
 ['Beechcraft','King Air 200 / B200','Twin Turboprop','Twin turboprop','light'],
 ['Beechcraft','King Air 250 / 260','Twin Turboprop','Twin turboprop','light'],
 ['Beechcraft','King Air 300 / 350 / 350i / 360','Twin Turboprop','Twin turboprop','light'],
 ['Beechcraft','King Air 1900','Twin Turboprop','Twin turboprop','large'],
 ['Piper','Cheyenne I / II / III / 400LS','Twin Turboprop','Twin turboprop','light'],
 ['Piper','PA-42 Cheyenne 400LS','Twin Turboprop','Twin turboprop','light'],
 ['Cessna','Conquest I 425','Twin Turboprop','Twin turboprop','small'],
 ['Cessna','Conquest II 441','Twin Turboprop','Twin turboprop','light'],
 ['Mitsubishi','MU-2','Twin Turboprop','Twin turboprop','light'],
 ['Piaggio','P.180 Avanti / Avanti II','Twin Turboprop','Twin turboprop','light'],
 ['Daher','TBM 700 / 850 / 900 / 940 / 960','Single Turboprop','Single turboprop','small'],
 ['Pilatus','PC-12 / PC-12 NG / NGX','Single Turboprop','Single turboprop','small'],
 ['Piper','M500 / M600 / M700 Fury','Single Turboprop','Single turboprop','small'],
 ['Epic','E1000','Single Turboprop','Single turboprop','small'],
 ['Cessna','Caravan 208 / 208B','Single Turboprop','Single turboprop','small'],
 ['Cirrus','SR20 / SR22 / SR22T','Single Piston','Single piston','small'],
 ['Cessna','172 Skyhawk','Single Piston','Single piston','small'],
 ['Cessna','182 Skylane','Single Piston','Single piston','small'],
 ['Piper','PA-28 Archer / Warrior','Single Piston','Single piston','small'],
 ['Piper','PA-46 Malibu / Mirage','Single Piston','Single piston','small'],
 ['Beechcraft','Baron 55 / 58 / G58','Twin Piston','Twin piston','small'],
 ['Piper','PA-34 Seneca','Twin Piston','Twin piston','small'],
 ['Piper','PA-44 Seminole','Twin Piston','Twin piston','small'],
 ['Cessna','310 / 340 / 414 / 421','Twin Piston','Twin piston','small']
].map((a,i)=>({id:i,maker:a[0],model:a[1],category:a[2],engine:a[3],tier:a[4]}));
const $=id=>document.getElementById(id);const usd=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const tier=id=>TIERS.find(t=>t.id===id)||TIERS[0];
const sorted=[...DATA].sort((a,b)=>a.maker.localeCompare(b.maker)||a.model.localeCompare(b.model));
$('aircraftCount').textContent=DATA.length;$('year').textContent=new Date().getFullYear();
$('categoryFilter').innerHTML+=[...new Set(DATA.map(a=>a.category))].sort().map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
$('makerFilter').innerHTML+=[...new Set(DATA.map(a=>a.maker))].sort().map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
$('tierSelect').innerHTML=TIERS.map(t=>`<option value="${t.id}">${esc(t.name)}</option>`).join('');
$('aircraftSelect').innerHTML+=sorted.map(a=>`<option value="${a.id}">${esc(a.maker+' '+a.model)}</option>`).join('');
$('priceRows').innerHTML=TIERS.map(t=>`<tr><td><strong>${esc(t.name)}</strong></td><td>${usd(t.handling)}</td><td>${t.waiver} gal</td><td>${usd(t.hangar)} / night</td></tr>`).join('');
$('serviceCards').innerHTML=SERVICES.map(([name,price])=>`<div class="servicecard"><span>${esc(name)}</span><strong>${esc(price)}</strong></div>`).join('');
function renderAircraft(){const q=$('search').value.trim().toLowerCase(),cat=$('categoryFilter').value,maker=$('makerFilter').value;const rows=sorted.filter(a=>(cat==='all'||a.category===cat)&&(maker==='all'||a.maker===maker)&&[a.maker,a.model,a.category,a.engine,tier(a.tier).name].some(s=>s.toLowerCase().includes(q)));$('resultCount').textContent=`Showing ${rows.length} of ${DATA.length} aircraft entries`;$('aircraftRows').innerHTML=rows.length?rows.map(a=>`<tr><td>${esc(a.maker)}</td><td><strong>${esc(a.model)}</strong></td><td>${esc(a.category)}</td><td>${esc(a.engine)}</td><td><span class="pill">${esc(tier(a.tier).name)}</span></td><td><button class="smallbtn" data-aircraft="${a.id}">Estimate ↗</button></td></tr>`).join(''):'<tr><td colspan="6">No matching aircraft. Try a different search.</td></tr>'}
['search','categoryFilter','makerFilter'].forEach(id=>$(id).addEventListener(id==='search'?'input':'change',renderAircraft));
$('clearFilters').addEventListener('click',()=>{$('search').value='';$('categoryFilter').value='all';$('makerFilter').value='all';renderAircraft()});
$('aircraftRows').addEventListener('click',e=>{const btn=e.target.closest('[data-aircraft]');if(!btn)return;setAircraft(btn.dataset.aircraft);$('calculator').scrollIntoView({behavior:'smooth'})});
function setAircraft(id){$('aircraftSelect').value=id;const a=DATA.find(x=>String(x.id)===String(id));if(a)$('tierSelect').value=a.tier;calculate()}
$('aircraftSelect').addEventListener('change',e=>{if(e.target.value!=='')setAircraft(e.target.value);else calculate()});
$('tierSelect').addEventListener('change',()=>{$('aircraftSelect').value='';calculate()});
const numeric=['jetGallons','jetPrice','avgasGallons','avgasPrice','hangarNights','afterHours','gpuCount','lavCount','preheatCount','pluginCount'];
function val(id){const n=Number($(id).value);return Number.isFinite(n)?Math.max(0,n):0}
let currentText='';
function calculate(){const t=tier($('tierSelect').value),jet=val('jetGallons'),avgas=val('avgasGallons'),fuel=jet*val('jetPrice')+avgas*val('avgasPrice');const qualifying=jet+avgas>=t.waiver;const handling=qualifying&&!$('overrideHandling').checked?0:t.handling;const lines=[['Jet-A fuel',jet*val('jetPrice')],['100LL fuel',avgas*val('avgasPrice')],['Handling fee',handling],['Winter hangar',val('hangarNights')*t.hangar],['After-hours callout',val('afterHours')*150],['GPU service',val('gpuCount')*75],['Lavatory service',val('lavCount')*75],['Preheat',val('preheatCount')*25],['Plug-in',val('pluginCount')*10],['Overnight ramp parking',0]];const total=lines.reduce((sum,[,amount])=>sum+amount,0);$('breakdown').innerHTML=lines.map(([name,amount])=>`<div class="lineitem"><span>${esc(name)}</span><strong>${usd(amount)}</strong></div>`).join('');$('grandTotal').textContent=usd(total);$('waiverNote').textContent=qualifying?($('overrideHandling').checked?'Fuel threshold met; handling charge manually retained.':'Fuel threshold met; handling fee waived.'): `Fuel waiver requires ${t.waiver} gallons (${Math.max(0,t.waiver-jet-avgas).toFixed(1)} more gallons).`;currentText=['KIOW Front Desk — FBO estimate',`Pricing tier: ${t.name}`,`Aircraft: ${$('aircraftSelect').selectedOptions[0]?.textContent||'Not selected'}`,...lines.map(([n,v])=>`${n}: ${usd(v)}`),`ESTIMATED TOTAL: ${usd(total)}`,'Reference estimate only. Confirm charges before quoting.'].join('\n')}
numeric.forEach(id=>$(id).addEventListener('input',calculate));$('overrideHandling').addEventListener('change',calculate);
$('resetCalc').addEventListener('click',()=>{numeric.forEach(id=>$(id).value='0');$('aircraftSelect').value='';$('tierSelect').value='small';$('overrideHandling').checked=false;calculate()});
$('copyEstimate').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(currentText);$('copyStatus').textContent='Estimate copied to clipboard.'}catch{$('copyStatus').textContent='Copy unavailable. Use Print estimate instead.'}});
$('printEstimate').addEventListener('click',()=>{const win=window.open('','_blank');if(!win){alert('Allow pop-ups to print the estimate.');return}win.document.write('<!doctype html><html><head><title>KIOW FBO Estimate</title><style>body{font:16px/1.7 system-ui;max-width:700px;margin:40px auto;padding:20px}pre{white-space:pre-wrap;font:inherit}</style></head><body><pre>'+esc(currentText)+'</pre></body></html>');win.document.close();win.focus();win.print()});
renderAircraft();calculate();
